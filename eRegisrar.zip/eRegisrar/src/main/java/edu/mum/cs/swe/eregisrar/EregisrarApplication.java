package edu.mum.cs.swe.eregisrar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EregisrarApplication {

    public static void main(String[] args) {
        SpringApplication.run(EregisrarApplication.class, args);
    }

}
